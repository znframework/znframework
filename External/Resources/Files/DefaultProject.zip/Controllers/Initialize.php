<?php namespace Project\Controllers;

class Initialize extends Controller
{
    public function main(String $params = NULL)
    {  
        \Permission::roleId(\User::data()->role);

        if( ! \Permission::page() )
        {
            \Redirect::location('Authorization/noperm');
        }
    } 
}