<?php namespace Project\Controllers;

class Cache extends Controller
{
    public function insert(String $params = NULL)
    {  
        \Cache::insert('key', 1);
    } 

    public function select()
    {
        echo \Cache::select('key');
    }

    public function delete()
    {
        \Cache::delete('key');
    }
}