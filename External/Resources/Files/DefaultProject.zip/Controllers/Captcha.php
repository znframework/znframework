<?php namespace Project\Controllers;

class Captcha extends Controller
{
    public function create(String $params = NULL)
    {  
        echo \Captcha::size(250, 60)
        ->length(8)
        ->borderColor('0|0|255')
        ->bgColor('255|255|255')
        ->textSize(5)
        ->textCoordinate(90,22)
        ->create(true);
    } 
}