<?php namespace Project\Controllers;

class Authentication extends Controller
{
    public function main(String $params = NULL)
    {  
        
    } 

    public function update()
    {
        \User::update('6340', '1234', '1234');
    }

    public function logout()
    {
        \User::logout();
    }

    public function register()
    {
        \User::register(['username' => 'ozan', 'password' => '6340']);
    }

    public function data()
    {
        output(\User::data());
    }

    public function login()
    {
        \User::login('ozan', '1234');
    }

    public function __destruct()
    {
        echo \User::success();
        echo \User::error();
    }
}