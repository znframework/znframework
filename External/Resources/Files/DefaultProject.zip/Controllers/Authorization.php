<?php namespace Project\Controllers;

class Authorization extends Controller
{
    public function main(String $params = NULL)
    {  
        
    } 

    public function noperm(String $params = NULL)
    {  
        echo 'No Permission!';
    } 
}