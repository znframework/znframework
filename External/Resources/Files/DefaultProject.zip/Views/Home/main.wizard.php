<div id="container">
    <div id="content">
        <div id="title">ZN <span class="blue-color">5.9</span> is dedicated to <span class="blue-color">{{ZN_DEDICATE}}</span></div>
        <div id="sub-title" class="grey-color">There is only one happiness in this life, to love and be loved.</div>
        <div id="spacex-logo"></div>
    </div>
</div>