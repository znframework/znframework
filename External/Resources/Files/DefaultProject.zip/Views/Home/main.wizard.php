<div id="container">
    <div id="content">
        <div id="title">{{$pageTitle}} {{ZN_VERSION}} is dedicated to <span class="blue-color">{{ZN_DEDICATE}}</span></div>
        <div id="sub-title">{{$pageSubtitle}}</div>
    </div>
</div>