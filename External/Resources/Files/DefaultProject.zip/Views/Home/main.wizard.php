<div id="container">
    <div id="content">
        <div id="title">ZN <span class="blue-color">EON</span> is dedicated to <span class="blue-color">{{ZN_DEDICATE}}</span></div>
        <div id="sub-title" class="grey-color">Maybe the sunset is an incredible opportunity to find new horizons.</div>
    </div>
</div>