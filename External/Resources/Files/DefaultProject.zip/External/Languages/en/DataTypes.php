<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Arrays
    |--------------------------------------------------------------------------
    |
    | The language of the Arrays library.
    |
    */
    
    'array:notExceedLength' => '`%` parameter can not exceed the length of `#` parameter!'
];
