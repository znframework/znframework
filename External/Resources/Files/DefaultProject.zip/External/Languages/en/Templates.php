<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Templates
    |--------------------------------------------------------------------------
    |
    | The language of the Templates.
    |
	*/

    'type'    => 'Type',
    'line'    => 'Line',
    'message' => 'Error',
    'file'    => 'File',
    'trace'   => 'Trace'
];
