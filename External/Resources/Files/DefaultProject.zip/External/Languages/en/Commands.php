<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Commands
    |--------------------------------------------------------------------------
    |
    | The language of the Commands library.
    |
    */
    
    'invalidCommand'     => '`%` Invalid Command!',
    'emptyCommand'       => 'The command parameter is empty!',
    'canNotCommandClass' => '[Command classes] can only be used with [console] commands!'
];
