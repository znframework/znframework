<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Database
    |--------------------------------------------------------------------------
    |
    | The language of the Database library.
    |
	*/

    'tableNotExistsError'           => '`%` tablosu bulunamadı!',
    'updateError'                   => 'Güncelleme işlemi gerçekleştirilemedi!',
    'connectError'                  => 'HATA: Veritabanı bağlantısı sağlanamadı! Lütfen bağlantı ayarlarınızı kontrol edin.',
    'duplicateCheckError'           => '`%` sütun veya sütunları daha önce aynı değere sahip olduğu için eklenemedi!',
    'optimizeTablesSuccess'         => 'Optimizasyon işlemi başarı ile tamamlandı.',
    'backupTablesSuccess'           => 'Yedekleme işlemi başarı ile tamamlandı.',
    'repairTablesSuccess'           => 'Onarma işlemi başarı ile tamamlandı.'   
];
