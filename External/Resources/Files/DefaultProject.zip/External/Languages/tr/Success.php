<?php return
[
    'success' => 'İşlem başarı ile tamamlandı.'
];