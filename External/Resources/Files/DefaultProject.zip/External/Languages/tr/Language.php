<?php return
[
    /*
    |--------------------------------------------------------------------------
    | ML
    |--------------------------------------------------------------------------
    |
    | The language of the ML library.
    |
    */
    
    'ml:addButton'              => 'Yeni Ekle',
    'ml:updateButton'           => 'Güncelle',
    'ml:deleteButton'           => 'Sil',
    'ml:clearButton'            => 'Temizle',
    'ml:searchButton'           => 'Ara',
    'ml:titleLabel'             => 'Çoklu Dil Veri Tablosu',
    'ml:confirmLabel'           => 'Bu işlemi yapmak istediğinizden emin misiniz?',
    'ml:keywordsLabel'          => 'Anahtar Kelimeler',
    'ml:processLabel'           => 'İşlemler',
    'ml:addLanguagePlaceHolder' => 'Dil Ekle',
    'ml:keywordPlaceHolder'     => 'Yeni Anahtar',
    'ml:searchPlaceHolder'      => 'Kelime Ara'
];