<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Arrays
    |--------------------------------------------------------------------------
    |
    | The language of the Arrays library.
    |
    */
    
    'array:notExceedLength' => '`%` parametre, `#` parametre uzunluğunu geçemez!'
];
