<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Commands
    |--------------------------------------------------------------------------
    |
    | The language of the Commands library.
    |
	*/

    'invalidCommand'     => '`%` Geçersiz komut!',
    'emptyCommand'       => 'Komut parametresi boş!',
    'canNotCommandClass' => '[Komut sınıfları] sadece [konsol] komutları ile kullanılabilir!'
];
