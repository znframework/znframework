<?php
/*
|--------------------------------------------------------------------------
| Top
|--------------------------------------------------------------------------
|
| The codes that are required to be run on the top layer of the system 
| are written.
|
| Location: After the system constants, before the Autoloader operation
|
*/
