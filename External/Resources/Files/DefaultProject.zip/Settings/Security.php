<?php return
[
    /*
    |--------------------------------------------------------------------------
    | URL Change Chars
    |--------------------------------------------------------------------------
    |
    | It is used to filter the data coming from the URL.
    |
    | Example: 'old_chars' => 'change_new_chars'
    | 
    */

    'urlChangeChars' =>
    [
        '<' => '',
        '>' => ''
    ]
];
