<?php
//-------------------------------------------------------------------------
// This file automatically created and updated
//-------------------------------------------------------------------------

class Migrateusers extends StaticAccess
{
	const table = __CLASS__;

	public static function getClassName()
	{
		return __CLASS__;
	}
}

//-------------------------------------------------------------------------