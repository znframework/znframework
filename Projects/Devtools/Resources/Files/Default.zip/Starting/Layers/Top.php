<?php
//--------------------------------------------------------------------------------------------------
// Top
//--------------------------------------------------------------------------------------------------
//
// Sistemin en üst katmanında çalıştırılmak istenen kodlar yazılır.
// Sistemin en üstünde çalıştığından autoloader devreye girmeden çalıştırılacak kodlar yazılabilir.
// Dolayısı ile ZN'ye ait hiç bir kütüphane bu katmanda kullanılamaz.
//
// Konum
//
// Sistem sabitlerinden sonra, Autoloader işleminden önce
// 
//--------------------------------------------------------------------------------------------------
