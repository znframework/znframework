<?php
//--------------------------------------------------------------------------------------------------
// Middle Bottom
//--------------------------------------------------------------------------------------------------
//
// Sistemin orta katmanının bir altında çalıştırılmak istenen kodlar yazılır.
// Çekirdek çalıştırılmasından sonra devreye girer..
//
// Konum
//
// Çekirdek çalıştırılmasından sonra, Çekirdek bitişinden önce
// 
//--------------------------------------------------------------------------------------------------
